//
//  GameViewController.swift
//  QuizGame
//
//  Created by Ryan Hutchens on 4/16/25.
//

import UIKit

class GameViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var gameModels = [Question]()
    var currentQuestion: Question?
    
    @IBOutlet var label: UILabel!
    @IBOutlet var table: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        table.delegate = self
        table.dataSource = self
        setupQuestions()
    }

    private func setupQuestions() {
        fetchTriviaQuestions { [weak self] questions in
            guard let self = self else { return }
            self.gameModels = questions
            if let first = questions.first {
                self.configureUI(question: first)
            }
        }
    }

    private func configureUI(question: Question) {
        label.text = question.text
        currentQuestion = question
        table.reloadData()
    }
    
    private func checkAnswer(answer: Answer, question: Question) -> Bool {
        return question.answers.contains(where: { $0.text == answer.text }) && answer.correctAnswer
    }
    
    func fetchTriviaQuestions(completion: @escaping ([Question]) -> Void) {
        guard let url = URL(string: "https://opentdb.com/api.php?amount=10&category=15&type=multiple") else { return }

        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                print("Network error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                let result = try JSONDecoder().decode(APIResponse.self, from: data)
                let questions = result.results.map { apiQ in
                    var answers = apiQ.incorrect_answers.map {
                        Answer(text: $0.decoded, correctAnswer: false)
                    }
                    answers.append(Answer(text: apiQ.correct_answer.decoded, correctAnswer: true))
                    answers.shuffle()
                    return Question(text: apiQ.question.decoded, answers: answers)
                }

                DispatchQueue.main.async {
                    completion(questions)
                }
            } catch {
                print("Decoding error: \(error)")
            }
        }
        task.resume()
    }

    // MARK: - TableView
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentQuestion?.answers.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = currentQuestion?.answers[indexPath.row].text
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        guard let question = currentQuestion else { return }
        
        let answer = question.answers[indexPath.row]
        
        if checkAnswer(answer: answer, question: question) {
            if let index = gameModels.firstIndex(where: { $0.text == question.text }) {
                if index < gameModels.count - 1 {
                    let nextQuestion = gameModels[index + 1]
                    currentQuestion = nil
                    configureUI(question: nextQuestion)
                } else {
                    let alert = UIAlertController(title: "Done", message: "You did it! You beat the game!", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel))
                    present(alert, animated: true)
                }
            }
        } else {
            let alert = UIAlertController(title: "Wrong", message: "Sorry! You chose the wrong answer.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel))
            present(alert, animated: true)
        }
    }
}

// MARK: - Models

struct Question {
    let text: String
    let answers: [Answer]
}

struct Answer {
    let text: String
    let correctAnswer: Bool
}

struct APIResponse: Codable {
    let results: [APIQuestion]
}

struct APIQuestion: Codable {
    let question: String
    let correct_answer: String
    let incorrect_answers: [String]
}

// MARK: - HTML Decoder Helper

extension String {
    var decoded: String {
        guard let data = self.data(using: .utf8) else { return self }
        let options: [NSAttributedString.DocumentReadingOptionKey: Any] = [
            .documentType: NSAttributedString.DocumentType.html,
            .characterEncoding: String.Encoding.utf8.rawValue
        ]
        let decoded = try? NSAttributedString(data: data, options: options, documentAttributes: nil)
        return decoded?.string ?? self
    }
}
